from django.shortcuts import render
# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
#def store(request):
    #return HttpResponse("Chào mừng các bạn đến với trang web onlineshop")
def store(request):
    return render(request, 'store.html',{})
def cart(request):
    return render(request, 'cart.html')
def checkout(request):
    return render(request, 'checkout.html',{})


